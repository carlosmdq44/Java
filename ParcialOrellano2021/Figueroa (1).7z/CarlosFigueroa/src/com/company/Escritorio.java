package com.company;

public class Escritorio extends Producto{
        private int ancho;
        private int alto;
        private final int aumento= 10;

    public Escritorio(int stock, String nombre, double precio, int ancho, int alto) {
        super(stock, nombre, precio);
        this.ancho = ancho;
        this.alto = alto;
    }

    public int getAncho() {
        return ancho;
    }

    public void setAncho(int ancho) {
        this.ancho = ancho;
    }

    public int getAlto() {
        return alto;
    }

    public void setAlto(int alto) {
        this.alto = alto;
    }

    @Override
    public String toString() {
        return "Escritorio{" +
                "ancho=" + ancho +
                ", alto=" + alto +
                ", Stock="+getStock() +
                ", Nombre="+getNombre() +
                ", Precio="+getPrecio() +
                "} ";
    }

    @Override
    public void aumentarPrecio() {

        setPrecio(getPrecio() + (getPrecio() * aumento/100));

    }
}
