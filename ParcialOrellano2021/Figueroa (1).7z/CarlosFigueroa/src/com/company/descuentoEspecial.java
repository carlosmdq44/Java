package com.company;

public interface descuentoEspecial {
    public double descuento (double porcentaje );
}
