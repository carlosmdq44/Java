package com.company;

public class Silla extends Producto{
    private boolean existeRueda;
    private final int aumento= 5;

    public Silla(int stock, String nombre, double precio, boolean existeRueda) {
        super(stock, nombre, precio);
        this.existeRueda = existeRueda;
    }

    public boolean isExisteRueda() {
        return existeRueda;
    }

    public void setExisteRueda(boolean existeRueda) {
        this.existeRueda = existeRueda;
    }

    @Override
    public String toString() {

        String rueda="No tiene rueda";
        if(existeRueda){
            rueda="Tiene rueda";
        }
        return "Silla{" +
                rueda +
                ", Stock="+getStock() +
                ", Nombre="+getNombre() +
                ", Precio="+getPrecio() +
                "} ";
    }

    @Override
    public double descuento(double porcentaje) {
            double total;
            total = getPrecio() - (getPrecio()*(porcentaje/100));
        return total;
    }
    @Override
    public void aumentarPrecio() {

        setPrecio(getPrecio() + (getPrecio() * aumento/100));

    }
}
