package com.company;

import java.util.ArrayList;
import com.company.*;
public class Main {

    public static void main(String[] args) {

        ////         EJERCICIO 1 / 2

        Producto escritorio = new Escritorio(2,"Mesa Escritorio",2500,150,300);
        Producto silla = new Silla(6,"Silla 1 ",2400,true);
        Producto impresora = new Impresora(5,"impresora",5500,"Samsung",500);
        Producto notebook = new Notebook(10,"Lenovo",150000,"Lenovo2",6);


        ////          EJERCICIO 3

        ArrayList<Producto> listaProducto = new ArrayList<>();
        listaProducto.add(escritorio);
        listaProducto.add(silla);
        listaProducto.add(impresora);
        listaProducto.add(notebook);

        ////          EJERCICIO 4

        for (Producto prod:listaProducto){
            if(prod instanceof Escritorio){
                System.out.println("Producto escritorio: "+prod.toString());
            }else if(prod instanceof  Silla){
                System.out.println("Producto Silla: "+prod.toString());
            }else if(prod instanceof Impresora){
                System.out.println("Producto impresora: "+prod.toString());
            }else if(prod instanceof Notebook){
                System.out.println("Producto notebook: "+prod.toString());
            }
        }

        ////          EJERCICIO 5

        System.out.println("Total silla con descuento " + silla.descuento(10));
        System.out.println("Total impresora con descuento " +impresora.descuento(10));

        for (Producto prod:listaProducto){
            System.out.println("El nombre del producto "+prod.getNombre() + " su precio es: "+prod.getPrecio());
            prod.aumentarPrecio();
            System.out.println("El precio con aumento es: "+prod.getPrecio());
        }
    }
}
