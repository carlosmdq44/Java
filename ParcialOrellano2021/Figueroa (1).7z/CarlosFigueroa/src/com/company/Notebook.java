package com.company;

public class Notebook extends ProductoInformatico {
    private int cantidadMemoria;
    private final int aumento= 20;

    public Notebook(int stock, String nombre, double precio, String nombreFabricante, int cantidadMemoria) {
        super(stock, nombre, precio, nombreFabricante);
        this.cantidadMemoria = cantidadMemoria;
    }

    public int getCantidadMemoria() {
        return cantidadMemoria;
    }

    public void setCantidadMemoria(int cantidadMemoria) {
        this.cantidadMemoria = cantidadMemoria;
    }

    @Override
    public String toString() {
        return "Notebook{" +
                "cantidadMemoria=" + cantidadMemoria + " GB" +
                ", Stock="+getStock() +
                ", Nombre="+getNombre() +
                ", Precio="+getPrecio() +
                ", Nombre Fabricante="+getNombreFabricante()+
                "} ";
    }
    @Override
    public void aumentarPrecio() {

        setPrecio(getPrecio() + (getPrecio() * aumento/100));

    }
}
