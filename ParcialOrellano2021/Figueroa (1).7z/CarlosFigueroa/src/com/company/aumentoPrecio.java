package com.company;

public interface aumentoPrecio {
    public void aumentarPrecio();
}
