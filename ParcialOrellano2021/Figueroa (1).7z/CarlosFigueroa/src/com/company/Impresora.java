package com.company;

public class Impresora extends ProductoInformatico{
    private int cantidadCopias;
    private final int aumento= 15;


    public Impresora(int stock, String nombre, double precio, String nombreFabricante, int cantidadCopias) {
        super(stock, nombre, precio, nombreFabricante);
        this.cantidadCopias = cantidadCopias;
    }

    public int getCantidadCopias() {
        return cantidadCopias;
    }

    public void setCantidadCopias(int cantidadCopias) {
        this.cantidadCopias = cantidadCopias;
    }


    @Override
    public String toString() {
        return "Impresora{" +
                "cantidadCopias=" + cantidadCopias +
                ", Stock="+getStock() +
                ", Nombre="+getNombre() +
                ", Precio="+getPrecio() +
                ", Nombre Fabricante="+getNombreFabricante()+
                "} ";
    }

    @Override
    public double descuento(double porcentaje) {
        double total;
        total = getPrecio() - (getPrecio()*(porcentaje/100));
        return total;
    }

    @Override
    public void aumentarPrecio() {

        setPrecio(getPrecio() + (getPrecio() * aumento/100));

    }
}
